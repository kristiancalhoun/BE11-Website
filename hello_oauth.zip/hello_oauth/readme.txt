The Hello Twitter Oauth code is the simplest example of a single server use of OAuth on Twitter. 
It is released under GPL. You can find the latest version of this code on the 140dev tutorial
page for Hello Twitter Oauth: 
http://140dev.com/twitter-api-programming-tutorials/hello-twitter-oauth-php/

This code uses Matt Harris' Oauth library to do all the nasty bits. 
A copy of the library is included in this zip. You can always get the latest version at: 
https://github.com/themattharris/tmhOAuth

I hope this sample code helps you get started with the Twitter API calls that require OAuth.

- Adam Green
http://140dev.com
140dev@gmail.com
@140dev
781-879-2960